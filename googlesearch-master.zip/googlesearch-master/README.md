googlesearch
============

Google search from Python.

https://breakingcode.wordpress.com/2010/06/29/google-search-python/
